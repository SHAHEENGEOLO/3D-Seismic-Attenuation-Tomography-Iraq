#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
=========================================================================
  FAULT SEGMENT EXTRACTION FROM SEISMIC ATTENUATION TOMOGRAPHY
  Generates ESRI Shapefile with full geophysical attributes
=========================================================================
  Input:  Kirkuk_Attenuation_Tomography.nc (CF-1.8 NetCDF)
  Output: Iraq_Fault_Segments.shp/.shx/.dbf/.prj/.cpg

  Method:
    1. Multi-depth, multi-band gradient stacking of Qi and Qsct
    2. Edge detection + skeletonization for lineament extraction
    3. Branch-point splitting into individual segments
    4. Polyline fitting with ordered coordinates
    5. Full attribute computation per segment

  Requirements:
      pip install scipy numpy pandas scikit-image
      (shapefile is written in pure Python — no extra GIS library needed)
=========================================================================
"""
import os, sys, struct, datetime, warnings, math
import numpy as np
import pandas as pd
from scipy.io import netcdf_file
from scipy import ndimage
from scipy.interpolate import RegularGridInterpolator
from skimage import measure, morphology

warnings.filterwarnings("ignore")

# ═════════════════════════════════════════════════
#  CONFIG
# ═════════════════════════════════════════════════
NC_PATH = r"C:\Users\shahe\Desktop\Kirkuk SAC files\ast_outputs_kirkuk\Kirkuk_Attenuation_Tomography.nc"
OUT_DIR = os.path.join(os.path.dirname(NC_PATH), "fault_shapefiles")
os.makedirs(OUT_DIR, exist_ok=True)

SHP_NAME = "Iraq_Fault_Segments"
FILL = -9999.0
MIN_SEGMENT_PX = 3       # minimum pixels per segment
EVIDENCE_PERCENTILE = 78  # threshold percentile for fault detection
GAUSS_SIGMA = 1.2         # smoothing of evidence field

# Known named faults (lon, lat) for auto-naming
NAMED_FAULTS = {
    "Kirkuk Anticline":      (44.40, 35.47),
    "Zagros Suture Zone":    (45.50, 35.20),
    "Hamrin Thrust":         (43.50, 34.50),
    "Mosul Fault":           (43.15, 36.34),
    "Sirnak-Cizre Fault":    (42.50, 37.30),
    "Khanaqin Fault":        (45.39, 34.35),
    "Dukan Fault Zone":      (44.95, 35.95),
    "Tigris Lineament":      (43.00, 33.50),
    "Erbil Fault":           (44.01, 36.19),
    "Shaqlawa Thrust":       (44.32, 36.64),
    "Greater Zab Fault":     (43.80, 36.40),
    "Lesser Zab Fault":      (44.50, 35.10),
    "Makhul Thrust":         (43.80, 34.80),
    "Chemchemal Fault":      (45.10, 35.40),
    "Pirmam Anticline":      (45.50, 36.10),
    "Bai Hassan Fault":      (44.20, 35.60),
}


# ═════════════════════════════════════════════════
#  PURE-PYTHON SHAPEFILE WRITER
# ═════════════════════════════════════════════════
class ShapefileWriter:
    """Writes ESRI Shapefile (PolyLine) from scratch. No external libs."""

    POLYLINE = 3

    def __init__(self, basename):
        self.basename = basename
        self.records = []   # list of (points_list, attributes_dict)
        self.fields = []    # list of (name, type, size, decimal)

    def add_field(self, name, field_type='C', size=50, decimal=6):
        """Add attribute field. Types: C=char, N=numeric, F=float, L=logical."""
        self.fields.append((name[:10], field_type, size, decimal))

    def add_record(self, points, attributes):
        """Add a polyline record. points = [(lon,lat), ...]."""
        self.records.append((points, attributes))

    def save(self):
        self._write_prj()
        self._write_cpg()
        self._write_shp_shx()
        self._write_dbf()

    def _write_prj(self):
        with open(self.basename + ".prj", "w") as f:
            f.write('GEOGCS["GCS_WGS_1984",DATUM["D_WGS_1984",'
                    'SPHEROID["WGS_1984",6378137.0,298.257223563]],'
                    'PRIMEM["Greenwich",0.0],UNIT["Degree",0.0174532925199433]]')

    def _write_cpg(self):
        with open(self.basename + ".cpg", "w") as f:
            f.write("UTF-8")

    def _write_shp_shx(self):
        # Compute bounding box
        all_x = [p[0] for pts, _ in self.records for p in pts]
        all_y = [p[1] for pts, _ in self.records for p in pts]
        bbox = (min(all_x), min(all_y), max(all_x), max(all_y))

        shp = bytearray()
        shx = bytearray()
        offset = 50  # header is 100 bytes = 50 words

        for rec_num, (points, _) in enumerate(self.records):
            xs = [p[0] for p in points]
            ys = [p[1] for p in points]

            # Record content: shape_type(4) + bbox(32) + numParts(4) + numPoints(4) + parts(4) + points(16*n)
            content_len = 4 + 32 + 4 + 4 + 4 + 16 * len(points)
            record_len_words = content_len // 2

            # SHX entry
            shx += struct.pack(">II", offset, record_len_words)

            # SHP record header
            shp += struct.pack(">II", rec_num + 1, record_len_words)
            # SHP record content
            shp += struct.pack("<i", self.POLYLINE)                    # shape type
            shp += struct.pack("<dddd", min(xs), min(ys), max(xs), max(ys))  # bbox
            shp += struct.pack("<i", 1)                                # numParts
            shp += struct.pack("<i", len(points))                      # numPoints
            shp += struct.pack("<i", 0)                                # parts[0]
            for x, y in points:
                shp += struct.pack("<dd", x, y)

            offset += (content_len + 8) // 2  # +8 for record header

        # Write SHP
        shp_file_len = 50 + len(shp) // 2
        header = struct.pack(">i", 9994) + b'\x00' * 20 + struct.pack(">i", shp_file_len)
        header += struct.pack("<i", 1000)  # version
        header += struct.pack("<i", self.POLYLINE)
        header += struct.pack("<dddd", bbox[0], bbox[1], bbox[2], bbox[3])
        header += struct.pack("<dddd", 0, 0, 0, 0)  # Z, M ranges
        with open(self.basename + ".shp", "wb") as f:
            f.write(header)
            f.write(shp)

        # Write SHX
        shx_file_len = 50 + len(self.records) * 4
        header_shx = struct.pack(">i", 9994) + b'\x00' * 20 + struct.pack(">i", shx_file_len)
        header_shx += struct.pack("<i", 1000)
        header_shx += struct.pack("<i", self.POLYLINE)
        header_shx += struct.pack("<dddd", bbox[0], bbox[1], bbox[2], bbox[3])
        header_shx += struct.pack("<dddd", 0, 0, 0, 0)
        with open(self.basename + ".shx", "wb") as f:
            f.write(header_shx)
            f.write(shx)

    def _write_dbf(self):
        n_rec = len(self.records)
        n_fld = len(self.fields)
        header_size = 32 + n_fld * 32 + 1
        rec_size = 1 + sum(f[2] for f in self.fields)

        with open(self.basename + ".dbf", "wb") as f:
            # Header
            now = datetime.datetime.now()
            f.write(struct.pack("BBBB", 3, now.year - 1900, now.month, now.day))
            f.write(struct.pack("<i", n_rec))
            f.write(struct.pack("<HH", header_size, rec_size))
            f.write(b'\x00' * 20)

            # Field descriptors
            for name, ftype, size, dec in self.fields:
                f.write(name.encode('ascii').ljust(11, b'\x00'))
                f.write(ftype.encode('ascii'))
                f.write(b'\x00' * 4)
                f.write(struct.pack("BB", size, dec))
                f.write(b'\x00' * 14)

            f.write(b'\r')  # header terminator

            # Records
            for _, attrs in self.records:
                f.write(b' ')  # deletion flag
                for name, ftype, size, dec in self.fields:
                    val = attrs.get(name[:10], "")
                    if ftype in ('N', 'F'):
                        s = f"{val:{size}.{dec}f}" if isinstance(val, (int, float)) and not math.isnan(val) else ""
                        f.write(s[:size].rjust(size).encode('ascii'))
                    else:
                        s = str(val) if val is not None else ""
                        f.write(s[:size].ljust(size).encode('ascii', errors='replace'))

            f.write(b'\x1a')  # EOF


# ═════════════════════════════════════════════════
#  LOAD NETCDF
# ═════════════════════════════════════════════════
def load_nc(path):
    print(f"Loading {os.path.basename(path)}...")
    nc = netcdf_file(path, 'r', mmap=False)
    D = {}
    for vn in nc.variables:
        D[vn] = nc.variables[vn].data.copy()
    nc.close()
    for k in D:
        if D[k].dtype in [np.float32, np.float64]:
            D[k][D[k] == FILL] = np.nan
    return D


# ═════════════════════════════════════════════════
#  FAULT EVIDENCE COMPUTATION
# ═════════════════════════════════════════════════
def compute_fault_evidence(D):
    """
    Multi-depth, multi-band gradient stacking.
    Returns: evidence_field [ny, nx], gradient_direction [ny, nx]
    """
    print("Computing fault evidence field (multi-depth, multi-band)...")
    lons = D["longitude"]; lats = D["latitude"]; depths = D["depth"]
    dlon = lons[1] - lons[0]; dlat = lats[1] - lats[0]
    cos_lat = np.cos(np.radians(np.mean(lats)))
    ny, nx = len(lats), len(lons)

    evidence = np.zeros((ny, nx), dtype=np.float64)
    gx_acc = np.zeros_like(evidence)
    gy_acc = np.zeros_like(evidence)
    weight_acc = np.zeros_like(evidence)

    for iz in range(len(depths)):
        # Weight: shallow crust weighted more, deep weighted less
        depth_w = max(0.2, 1.0 - depths[iz] / 20.0)

        for b in range(4):
            band_w = [0.6, 0.8, 1.0, 0.9][b]  # Band 2 (3-6 Hz) weighted highest

            # Qi gradient
            arr = np.nan_to_num(D["Qi_inv"][b, iz], nan=0)
            gy, gx = np.gradient(arr, dlat * 111, dlon * 111 * cos_lat)
            gmag = np.sqrt(gx**2 + gy**2)
            w = depth_w * band_w
            evidence += w * gmag

            # Qsct gradient (scattering heterogeneity = fault complexity)
            arr2 = np.nan_to_num(D["Qsct_inv"][b, iz], nan=0)
            gy2, gx2 = np.gradient(arr2, dlat * 111, dlon * 111 * cos_lat)
            evidence += w * 0.5 * np.sqrt(gx2**2 + gy2**2)

            # Accumulate direction (weighted by magnitude)
            gx_acc += gx * gmag * w
            gy_acc += gy * gmag * w
            weight_acc += gmag * w

    evidence /= (len(depths) * 4)

    # Fault strike = perpendicular to gradient direction
    with np.errstate(divide='ignore', invalid='ignore'):
        grad_direction = np.degrees(np.arctan2(gy_acc, gx_acc)) % 180
    fault_strike = (grad_direction + 90) % 180

    print(f"  Evidence range: [{evidence.min():.6f}, {evidence.max():.6f}]")
    print(f"  P80={np.percentile(evidence, 80):.6f}, P90={np.percentile(evidence, 90):.6f}")

    return evidence, fault_strike


# ═════════════════════════════════════════════════
#  SEGMENT EXTRACTION
# ═════════════════════════════════════════════════
def extract_segments(evidence, fault_strike, lons, lats):
    """
    Threshold → skeletonize → split at branches → trace polylines.
    Returns list of segment dicts with pixel coordinates.
    """
    print("Extracting fault segments...")

    # Smooth to connect nearby features
    ev_smooth = ndimage.gaussian_filter(evidence, sigma=GAUSS_SIGMA)

    # Threshold
    thresh = np.percentile(ev_smooth, EVIDENCE_PERCENTILE)
    binary = ev_smooth > thresh
    binary = morphology.remove_small_objects(binary, min_size=MIN_SEGMENT_PX)
    binary = morphology.closing(binary, morphology.disk(1))

    # Skeletonize to thin lines
    skeleton = morphology.skeletonize(binary)

    # Find and remove branch points to split at junctions
    kernel = np.ones((3, 3)); kernel[1, 1] = 0
    nbr_count = ndimage.convolve(skeleton.astype(int), kernel)
    branch_pts = skeleton & (nbr_count > 2)
    skeleton_split = skeleton.copy()
    skeleton_split[branch_pts] = False

    # Label connected segments
    labels = measure.label(skeleton_split)
    n_raw = labels.max()
    print(f"  Threshold: {thresh:.6f} (P{EVIDENCE_PERCENTILE})")
    print(f"  Raw skeleton segments: {n_raw}")

    segments = []
    for seg_id in range(1, n_raw + 1):
        mask = labels == seg_id
        npix = mask.sum()
        if npix < MIN_SEGMENT_PX:
            continue

        ys, xs = np.where(mask)

        # Order points along the segment (greedy nearest-neighbor walk)
        coords = list(zip(xs.tolist(), ys.tolist()))
        ordered = [coords.pop(0)]
        while coords:
            last = ordered[-1]
            dists = [(c[0]-last[0])**2 + (c[1]-last[1])**2 for c in coords]
            nearest = np.argmin(dists)
            ordered.append(coords.pop(nearest))

        # Convert to lon/lat
        points = [(lons[x], lats[y]) for x, y in ordered]

        # Segment evidence values
        ev_vals = [evidence[y, x] for x, y in ordered]
        strike_vals = [fault_strike[y, x] for x, y in ordered]

        segments.append({
            "seg_id": seg_id,
            "points": points,
            "pixel_coords": ordered,
            "npix": npix,
            "evidence_mean": np.mean(ev_vals),
            "evidence_max": np.max(ev_vals),
            "strike_mean": np.mean(strike_vals),
        })

    print(f"  Valid segments: {len(segments)}")
    return segments


# ═════════════════════════════════════════════════
#  ATTRIBUTE COMPUTATION
# ═════════════════════════════════════════════════
def compute_attributes(segments, D):
    """Compute full geophysical attributes for each segment."""
    print("Computing segment attributes...")

    lons = D["longitude"]; lats = D["latitude"]; depths = D["depth"]
    cos_lat = np.cos(np.radians(np.mean(lats)))
    band = 2  # primary band for characterization

    results = []
    for seg in segments:
        pts = seg["points"]
        pxs = seg["pixel_coords"]
        n = len(pts)

        # ── Geometry ──
        start_lon, start_lat = pts[0]
        end_lon, end_lat = pts[-1]
        center_lon = np.mean([p[0] for p in pts])
        center_lat = np.mean([p[1] for p in pts])

        # Segment length (km)
        seg_length = 0
        for i in range(1, n):
            dx = (pts[i][0] - pts[i-1][0]) * 111 * cos_lat
            dy = (pts[i][1] - pts[i-1][1]) * 111
            seg_length += np.sqrt(dx**2 + dy**2)

        # Overall trend (azimuth from start to end)
        dx_total = (end_lon - start_lon) * 111 * cos_lat
        dy_total = (end_lat - start_lat) * 111
        trend_deg = np.degrees(np.arctan2(dx_total, dy_total)) % 180
        if trend_deg > 180: trend_deg -= 180

        # Segment width (perpendicular extent of evidence above threshold)
        dlon = lons[1] - lons[0]; dlat = lats[1] - lats[0]
        width_km = max(1, seg["npix"]) * min(dlon * 111 * cos_lat, dlat * 111) * 0.7

        # ── Attenuation sampling along segment ──
        qi_vals = []; qs_vals = []; qt_vals = []; qi_std_vals = []
        snr_vals = []; ratio_vals = []
        depth_qi_profiles = {z: [] for z in range(len(depths))}

        for px, py in pxs:
            ix = min(px, len(lons)-1); iy = min(py, len(lats)-1)
            for iz in range(len(depths)):
                qi = D["Qi_inv"][band, iz, iy, ix]
                qs = D["Qsct_inv"][band, iz, iy, ix]
                if np.isfinite(qi): depth_qi_profiles[iz].append(qi)

            # At z=5km
            iz5 = np.argmin(np.abs(depths - 5.0))
            qi = D["Qi_inv"][band, iz5, iy, ix]
            qs = D["Qsct_inv"][band, iz5, iy, ix]
            qt = D["Qt_inv"][band, iz5, iy, ix]
            qi_e = D["Qi_inv_std"][band, iz5, iy, ix]
            s = D["Qi_SNR"][band, iz5, iy, ix]
            r = D["Qsct_Qi_ratio"][band, iz5, iy, ix]

            if np.isfinite(qi): qi_vals.append(qi)
            if np.isfinite(qs): qs_vals.append(qs)
            if np.isfinite(qt): qt_vals.append(qt)
            if np.isfinite(qi_e): qi_std_vals.append(qi_e)
            if np.isfinite(s): snr_vals.append(s)
            if np.isfinite(r) and abs(r) < 100: ratio_vals.append(r)

        # ── Depth extent ──
        # Find maximum depth where Qi anomaly exceeds background
        max_depth = 0
        for iz in range(len(depths)):
            vals = depth_qi_profiles[iz]
            if vals and abs(np.mean(vals)) > 0.01:
                max_depth = depths[iz]
        min_depth = 0.0  # surface fault assumed

        # ── Fault classification ──
        mean_qi = np.mean(qi_vals) if qi_vals else 0
        mean_qs = np.mean(qs_vals) if qs_vals else 0
        mean_ratio = np.mean(ratio_vals) if ratio_vals else 1.0
        mean_snr = np.mean(snr_vals) if snr_vals else 0

        # Fault type based on geometry and attenuation pattern
        if trend_deg < 30 or trend_deg > 150:
            fault_type = "Thrust"
        elif 60 < trend_deg < 120:
            fault_type = "Strike-slip"
        else:
            fault_type = "Oblique"

        if mean_ratio > 1.3:
            fault_type = fault_type + " (fractured)"

        # Dip estimation (crude: from depth extent vs width)
        if width_km > 0 and max_depth > 0:
            dip_deg = np.degrees(np.arctan(max_depth / width_km))
        else:
            dip_deg = 60.0  # default moderate dip

        # Dip direction (perpendicular to strike, choose NE-side convention)
        dip_direction = (trend_deg + 90) % 360

        # Activity classification
        if mean_snr > 1.5 and abs(mean_qi) > 0.05:
            activity = "Active"
        elif mean_snr > 0.5 and abs(mean_qi) > 0.02:
            activity = "Potentially Active"
        else:
            activity = "Inactive/Uncertain"

        # ── Auto-name from nearest known fault ──
        min_dist = 999; best_name = f"Segment_{seg['seg_id']:03d}"
        for fname, (flon, flat) in NAMED_FAULTS.items():
            d = np.sqrt(((center_lon - flon)*111*cos_lat)**2 + ((center_lat - flat)*111)**2)
            if d < min_dist:
                min_dist = d; best_name = fname
        if min_dist > 80:
            # Too far from any named fault
            if center_lat > 37:
                region = "N_Iraq"
            elif center_lat > 35:
                region = "Kirkuk"
            elif center_lat > 33:
                region = "Hamrin"
            else:
                region = "Mesopot"
            best_name = f"{region}_Seg{seg['seg_id']:03d}"
        proximity = min_dist

        # ── Confidence grade ──
        if mean_snr > 2 and seg_length > 50:
            confidence = "A"
        elif mean_snr > 1 and seg_length > 20:
            confidence = "B"
        elif mean_snr > 0.3:
            confidence = "C"
        else:
            confidence = "D"

        rec = {
            "FaultName":  best_name,
            "FaultType":  fault_type,
            "SegLen_km":  round(seg_length, 1),
            "MinDep_km":  round(min_depth, 1),
            "MaxDep_km":  round(max_depth, 1),
            "Width_km":   round(width_km, 1),
            "Trend_deg":  round(trend_deg, 1),
            "Dip_deg":    round(dip_deg, 1),
            "DipDir_deg": round(dip_direction, 1),
            "Activity":   activity,
            "Qi_mean":    round(np.mean(qi_vals), 6) if qi_vals else 0,
            "Qi_std":     round(np.mean(qi_std_vals), 6) if qi_std_vals else 0,
            "Qsct_mean":  round(np.mean(qs_vals), 6) if qs_vals else 0,
            "Qt_mean":    round(np.mean(qt_vals), 6) if qt_vals else 0,
            "Ratio_QsQi": round(mean_ratio, 3),
            "SNR":        round(mean_snr, 2),
            "Evidence":   round(seg["evidence_mean"], 6),
            "Ev_max":     round(seg["evidence_max"], 6),
            "Confid":     confidence,
            "CenterLon":  round(center_lon, 4),
            "CenterLat":  round(center_lat, 4),
            "Proximity":  round(proximity, 1),
            "N_pixels":   seg["npix"],
        }
        rec["_points"] = pts
        results.append(rec)

    # Sort by evidence strength
    results.sort(key=lambda r: -r["Evidence"])

    # Assign rank
    for i, r in enumerate(results):
        r["Rank"] = i + 1

    print(f"  Attributed: {len(results)} segments")
    return results


# ═════════════════════════════════════════════════
#  SHAPEFILE OUTPUT
# ═════════════════════════════════════════════════
def write_shapefile(segments, out_dir, name):
    """Write complete shapefile with all attributes."""
    print(f"Writing shapefile: {name}...")

    shp = ShapefileWriter(os.path.join(out_dir, name))

    # Define fields
    shp.add_field("FaultName", "C", 40)
    shp.add_field("FaultType", "C", 30)
    shp.add_field("SegLen_km", "F", 10, 1)
    shp.add_field("MinDep_km", "F", 8, 1)
    shp.add_field("MaxDep_km", "F", 8, 1)
    shp.add_field("Width_km",  "F", 8, 1)
    shp.add_field("Trend_deg", "F", 8, 1)
    shp.add_field("Dip_deg",   "F", 8, 1)
    shp.add_field("DipDir_deg","F", 8, 1)
    shp.add_field("Activity",  "C", 25)
    shp.add_field("Qi_mean",   "F", 12, 6)
    shp.add_field("Qi_std",    "F", 12, 6)
    shp.add_field("Qsct_mean", "F", 12, 6)
    shp.add_field("Qt_mean",   "F", 12, 6)
    shp.add_field("Ratio_QsQi","F", 10, 3)
    shp.add_field("SNR",       "F", 8, 2)
    shp.add_field("Evidence",  "F", 12, 6)
    shp.add_field("Ev_max",    "F", 12, 6)
    shp.add_field("Confid",    "C", 2)
    shp.add_field("CenterLon", "F", 10, 4)
    shp.add_field("CenterLat", "F", 10, 4)
    shp.add_field("Proximity", "F", 8, 1)
    shp.add_field("N_pixels",  "N", 6, 0)
    shp.add_field("Rank",      "N", 4, 0)

    for seg in segments:
        pts = seg.pop("_points")
        shp.add_record(pts, seg)
        seg["_points"] = pts  # restore

    shp.save()
    print(f"  Written: {name}.shp/.shx/.dbf/.prj/.cpg")
    print(f"  Records: {len(segments)}")


# ═════════════════════════════════════════════════
#  SUMMARY TABLE
# ═════════════════════════════════════════════════
def write_summary(segments, out_dir):
    """Write CSV summary of all fault segments."""
    rows = []
    for s in segments:
        row = {k: v for k, v in s.items() if k != "_points"}
        rows.append(row)

    df = pd.DataFrame(rows)
    out = os.path.join(out_dir, "Fault_Segments_Summary.csv")
    df.to_csv(out, index=False)
    print(f"  Summary CSV: {out} ({len(df)} rows)")

    # Print compact table
    print(f"\n{'='*110}")
    print(f"  {'Rank':>4} {'Fault Name':28s} {'Type':20s} {'Len':>6} {'Depth':>8} "
          f"{'Trend':>6} {'Dip':>5} {'Activity':20s} {'Qi':>8} {'SNR':>5} {'Gr':>2}")
    print(f"{'='*110}")
    for _, r in df.iterrows():
        print(f"  {int(r.Rank):>4} {r.FaultName:28s} {r.FaultType:20s} "
              f"{r.SegLen_km:>6.1f} {r.MinDep_km:>3.0f}-{r.MaxDep_km:>3.0f}km "
              f"{r.Trend_deg:>6.1f} {r.Dip_deg:>5.1f} {r.Activity:20s} "
              f"{r.Qi_mean:>8.4f} {r.SNR:>5.2f} {r.Confid:>2s}")
    print(f"{'='*110}")
    return df


# ═════════════════════════════════════════════════
#  MAIN
# ═════════════════════════════════════════════════
def main():
    print("=" * 70)
    print("  FAULT SEGMENT EXTRACTION FROM ATTENUATION TOMOGRAPHY")
    print("  Iraq / Kirkuk Region")
    print("=" * 70)

    # Load
    D = load_nc(NC_PATH)

    # Compute evidence
    evidence, fault_strike = compute_fault_evidence(D)

    # Extract segments
    segments = extract_segments(evidence, fault_strike, D["longitude"], D["latitude"])

    # Compute attributes
    attributed = compute_attributes(segments, D)

    # Write shapefile
    write_shapefile(attributed, OUT_DIR, SHP_NAME)

    # Write summary
    df = write_summary(attributed, OUT_DIR)

    print(f"\n{'='*70}")
    print(f"  Output directory: {OUT_DIR}")
    print(f"  Shapefile: {SHP_NAME}.shp  ({len(attributed)} segments)")
    print(f"  Summary:   Fault_Segments_Summary.csv")
    print(f"{'='*70}")
    print(f"\n  SHAPEFILE FIELDS:")
    print(f"    FaultName   - Auto-assigned from nearest known fault")
    print(f"    FaultType   - Thrust / Strike-slip / Oblique (+ fractured)")
    print(f"    SegLen_km   - Along-strike length in km")
    print(f"    MinDep_km   - Minimum depth of detection")
    print(f"    MaxDep_km   - Maximum depth with anomaly > background")
    print(f"    Width_km    - Across-strike width of anomaly zone")
    print(f"    Trend_deg   - Strike azimuth (0-180)")
    print(f"    Dip_deg     - Dip angle from horizontal")
    print(f"    DipDir_deg  - Dip direction azimuth (0-360)")
    print(f"    Activity    - Active / Potentially Active / Inactive")
    print(f"    Qi_mean     - Mean intrinsic attenuation along segment")
    print(f"    Qi_std      - Uncertainty of Qi")
    print(f"    Qsct_mean   - Mean scattering attenuation")
    print(f"    Qt_mean     - Mean total attenuation")
    print(f"    Ratio_QsQi  - Qsct/Qi ratio (>1 = scattering dominant)")
    print(f"    SNR         - Signal-to-noise reliability")
    print(f"    Evidence    - Gradient evidence strength")
    print(f"    Confid      - Confidence grade (A/B/C/D)")
    print(f"    Rank        - Overall rank by evidence strength")
    print()


if __name__ == "__main__":
    main()
